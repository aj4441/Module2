import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userid : string;
    password : string;
    roles : string[];
    submitted : boolean;
    selected : string;


  constructor() {
    this.roles = ['Admin','User','Guest'];
    this.userid="";
    this.password="";
   }

  ngOnInit() {
  }


validate(){
  this.submitted= true;
  console.log(this.userid + "=" + this.password);
}
}



