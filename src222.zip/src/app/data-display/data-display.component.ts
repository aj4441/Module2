import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-display',
  templateUrl: './data-display.component.html',
  styleUrls: ['./data-display.component.css']
})
export class DataDisplayComponent implements OnInit {
  Employee: string[];
  EmployeeInfo:object;
  
  constructor() {

   };

  ngOnInit() {
this.Employee=['Ajay','Rahul','Shubham','Yogesh'];
this.EmployeeInfo=[
  {Name:'Ajay', Username: 'ajamrutk', Password:'asdf'},
  { Name:'Rahul',Username: 'raamrutk', Password:'adfg'},
  { Name:'Shubham',Username: 'shamrutk', Password:'asdk'},
  {Name:'Yogesh', Username: 'yoamrutk', Password:'asdl'}
];
}
}