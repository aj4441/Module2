import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { EmployeeModel } from '../models/Employee';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  employeeArr:EmployeeModel[];
  employeeToEdit:EmployeeModel;
  isEditing:boolean;

  constructor(private empService:EmployeeService) { 
    this.employeeArr = [];
    this.employeeToEdit = new EmployeeModel()
  }

  ngOnInit() {
    this.employeeArr = this.empService.getEmployees();
  }

  sortEmp()
  {
    this.empService.sortEmp();
  }

  delete(index: number) {
   this.empService.delete(index);
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.employeeToEdit = this.empService.edit(id);
  }

}
