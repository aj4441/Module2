import { Injectable } from '@angular/core';
import { EmployeeModel } from '../model/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //create an array
  employeeArr : EmployeeModel[];

  static counter:number =1001;
//Initialize it in constructor
  constructor() { 
    this.employeeArr =[]
  }

  //adding method
  add(employee:EmployeeModel){
    employee.employeeId = EmployeeService.counter++;
    this.employeeArr.push(employee);
  }

  displays()
  {
    return this.employeeArr;
  }
}
