export class EmployeeModel{

        public employeeId:number;
        public employeeName:String;
        public employeeSalary:number;



}