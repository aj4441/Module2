import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../model/Employee';
import { EmployeeService } from '../Service/employee.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  employeeArr: EmployeeModel[];
  constructor(private employeeService:EmployeeService) {
    this.employeeArr=[]
   }

  ngOnInit() {
    this.employeeArr = this.employeeService.displays();
  }

}
