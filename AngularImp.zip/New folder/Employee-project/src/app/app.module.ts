import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { DisplayComponent } from './display/display.component';
import { RegistrationComponent } from './registration/registration.component';
import { AppRoutingModule } from './app-routing.module';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';
import { EmployeeService } from './Service/employee.service';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'register', component: RegistrationComponent, pathMatch: 'full' },
  { path: 'display', component: DisplayComponent, pathMatch: 'full' },
  { path: '**', redirectTo: 'register', pathMatch: 'full' },

]

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    RegistrationComponent
  ],
  imports: [
    BrowserModule, 
    RouterModule.forRoot(routes), 
    FormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }

