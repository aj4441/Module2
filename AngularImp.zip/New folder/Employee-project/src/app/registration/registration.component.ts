import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../model/Employee';
import { EmployeeService } from '../Service/employee.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  employee: EmployeeModel
  //reference of service to pass the data to service


  constructor(private empsService: EmployeeService) {
    
    //object
    this.employee= new EmployeeModel;
  }

  ngOnInit() {
  }

  insertEmployee()
  {
    this.empsService.add(this.employee)
  }

}
