import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css']
})
export class CouponsComponent implements OnInit {

  constructor() { }

  isValid:boolean = false;
  @Output() addedCoupon = new EventEmitter();

  ngOnInit() {
  }

  checkCoupon(code:String)
  {
      this.isValid = true;
  }
}
