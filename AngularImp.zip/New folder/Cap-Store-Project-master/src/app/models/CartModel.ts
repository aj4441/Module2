import { Customer } from './customerpage';
import { Product } from './Product';

export class Cart{
    public id:number;
    public customerFromCart:Customer;
    public cartProducts:Product[];
}