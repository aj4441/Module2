import { Product } from './Product';

export class Category{
    id:number;
    name:String;
    type:string
    productFromCategory:Product[]
}