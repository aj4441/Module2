import { NewPassword } from './new-password';

describe('NewPassword', () => {
  it('should create an instance', () => {
    expect(new NewPassword()).toBeTruthy();
  });
});
