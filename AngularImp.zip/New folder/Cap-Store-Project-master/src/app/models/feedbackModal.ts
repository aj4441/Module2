export class FeedBackModal {
  public id:number;
  public customerFirstName: string;
  public productComment: string;
  public productRating: string;
}
