import { CheckoutService } from './../services/checkout.service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AddressModel } from '../models/AddressModel';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {

  @Output() addedEvent = new EventEmitter();

  addLine1FormControl = new FormControl('', [
    Validators.required,
  ]);
  addLine2FormControl = new FormControl('', [
    Validators.required,
  ]);
  CityFormControl = new FormControl('', [
    Validators.required,
  ]);
  StateFormControl = new FormControl('', [
    Validators.required,
  ]);

  PinFormControl = new FormControl('', [
    Validators.required, Validators.maxLength(6)
  ]);

  constructor(public service: CheckoutService) {
    this.addressModel = new AddressModel();
  }

  addressModel: AddressModel;
  addressArray: AddressModel[] = []
  incorrectaddLine1 = false;
  incorrectaddLine2 = false;
  incorrectCity = false;
  incorrectState = false;

  isNewAddress: boolean = false;

  selectedAddress: boolean[] = []

  ngOnInit() {
    this.fetchAddress()
  }

  fetchAddress() {
    var id = JSON.parse(localStorage.getItem("user"))["id"];
    this.service.getAddress(id).subscribe(
      res => {
        this.addressArray = res;
        if (this.addressArray.length != 0)
        {
          this.selectedAddress[0] = true;
          this.service.addId = this.addressArray[0].id;
        }
      }, err => { console.log(err) }
    )
  }

  setAddress(i: number) {
    this.selectedAddress = []
    this.selectedAddress[i] = true;
    this.service.addId = this.addressArray[i].id;
  }

  addAddress() {
    if (this.addressModel.addLine1.length < 10 || this.addressModel.addLine1.length > 50) {
      this.incorrectaddLine1 = true;
    }
    else if (this.addressModel.addLine2.length < 10 || this.addressModel.addLine2.length > 50) {
      this.incorrectaddLine1 = false;
      this.incorrectaddLine2 = true;
    }
    else if (this.addressModel.city.length < 3 || this.addressModel.city.length > 20) {
      this.incorrectaddLine1 = false;
      this.incorrectaddLine2 = false;
      this.incorrectCity = true;
    }
    else if (this.addressModel.state.length < 3 || this.addressModel.state.length > 20) {
      this.incorrectaddLine1 = false;
      this.incorrectaddLine2 = false;
      this.incorrectCity = false;
      this.incorrectState = true;
    }
    else {
      var id = JSON.parse(localStorage.getItem("user"))["id"];
      this.service.setAddress(id, this.addressModel).subscribe(
        res => {
          this.addressModel = new AddressModel();
          this.isNewAddress = false
          this.fetchAddress()
        }, err => {
          console.log(err)
        }
      )
    }
  }
}
