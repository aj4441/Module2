import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/Product';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  products:Product[]=[];
  constructor(private productService:ProductService, 
    private route: ActivatedRoute) { }

  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.productService.categorySearch(id).subscribe(
      res=>{
        this.products = res.productFromCategory;
        console.log(this.products)
      },err=>{
        console.log(err)
      }
    )
  }

  sorter(type:string)
  {
      switch(type)
      {
        case "name":
        this.products.sort((a,b)=>a.name.localeCompare(b.name));
        break;

        case "lprice":
        this.products.sort((a,b)=>a.inventoryFromProduct[0].price-b.inventoryFromProduct[0].price);
        break;

        case "hprice":
        this.products.sort((a,b)=>b.inventoryFromProduct[0].price-a.inventoryFromProduct[0].price);
        break;

        default:break;
      }
  }
}
