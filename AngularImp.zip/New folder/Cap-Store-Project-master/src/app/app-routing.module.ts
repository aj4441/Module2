import { CategoryComponent } from './category/category.component';
import { ShippingComponent } from './shipping/shipping.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { LogonComponent } from './logon/logon.component';
import { RegisterComponent } from './register/register.component';
import { CustomerPageComponent } from './customer-page/customer-page.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'product/:id',component:ProductComponent,pathMatch:'full'},
  {path:'cart',component:CartComponent,pathMatch:'full'},
  {path:'wishlist',component:WishlistComponent,pathMatch:'full'},
  {path:'checkout',component:CheckoutComponent,pathMatch:'full'},
  {path: 'logon', component: LogonComponent,pathMatch:'full' },
  {path: 'register', component: RegisterComponent ,pathMatch:'full'},
  {path: 'customer-profile', component: CustomerPageComponent,pathMatch:'full' },
  {path: 'edit-customer', component: EditCustomerComponent,pathMatch:'full' },
  {path: 'changepassword', component: ChangepasswordComponent,pathMatch:'full'},
  {path: 'newpassword', component: NewpasswordComponent,pathMatch:'full'},
  {path: 'forgotpassword', component: ForgotpasswordComponent,pathMatch:'full'},
  {path: 'invoice', component: InvoiceComponent,pathMatch:'full'},
  {path: 'shipping', component: ShippingComponent,pathMatch:'full'},
  {path: 'search', component: SearchComponent,pathMatch:'full'},
  {path: 'category/:id', component: CategoryComponent,pathMatch:'full'},
  {path:'**',redirectTo:'',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
