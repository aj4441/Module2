import { Component, OnInit } from '@angular/core';
import { Registration } from './../models/registration';
import { ServiceService } from '../services/service.service';
import { Router } from '@angular/router';
import { Customer } from '../models/customerpage';
@Component({
  selector: 'app-customer-page',
  templateUrl: './customer-page.component.html',
  styleUrls: ['./customer-page.component.css']
})
export class CustomerPageComponent implements OnInit {

  registeredDetails: Registration;
  loggedCustomer:Customer;
  constructor(private serviceService: ServiceService, private router: Router) {
    this.registeredDetails = new Registration();
  }

  ngOnInit() {
      this.loggedCustomer = this.serviceService.loggedCustomer;
  }
  navigateToEdit() {
    this.router.navigate(['/edit-customer']);

  }

}
