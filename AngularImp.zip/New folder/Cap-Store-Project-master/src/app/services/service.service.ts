import { Logon } from './../models/logon';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Registration } from './../models/registration';
import { Router } from '@angular/router';
import { EditCustomer } from './../models/editcustomer';
import { Customer } from '../models/customerpage';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  logon = new Logon();
  receivedObj: Registration;
  baseHref = 'http://localhost:8888';
  public loggedCustomer:Customer=new Customer();
  public isLogged:boolean = false

  constructor(private http: HttpClient) {
  }

  login(logon: Logon) {
    return this.http.get<Customer>(this.baseHref + '/customer/?email='+logon.email+'&password='+logon.password);
  }
  registerDetails(register: Registration) {
    var body={
      firstName:register.firstname,
      lastName:register.lastname,
      email:register.email,
      password:register.password,
      contact:"8286703935"
    }
    return this.http.post<Logon>(this.baseHref + '/customer/add', body);
  }
  edit(editedDetails: EditCustomer): any {
    console.log(editedDetails);
    return this.http.post<Logon>(this.baseHref + '/edit', editedDetails);
  }

  checkLogin(){
    return this.http.get<Customer>(this.baseHref +'/customer/valid');
  }

  logOut(){
    return this.http.get<String>(this.baseHref +'/customer/logout');
  }
}
