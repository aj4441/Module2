import { CheckoutService } from './../services/checkout.service';
import { Component, OnInit } from '@angular/core';
import { Order } from '../models/OrderModel';
import { Customer } from '../models/customerpage';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {

  ngxQrcode2 = 'https://material.angular.io/components/snack-bar/overview';
  invoiceArr:Order[]=[]
  customer:Customer = JSON.parse(localStorage.getItem("user"));

  constructor(private service:CheckoutService) { }

  ngOnInit() {
    this.service.getOrders().subscribe(
        res=>{
          this.invoiceArr = res;
        },err=>{console.log(err)}
    )
  }
}
