import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskModel } from '../model/task-model';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  allTasks: TaskModel[];
  confirmationStatus;
  constructor(private router: Router, private taskService: TaskService) {
    this.allTasks = [];
    this.allTasks = this.taskService.display();
  }

  ngOnInit() {
  }
  addTask() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['/create']);
  }
  deleteTask(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.taskService.delete(index);
    }
  }
  editTask(index: number) {
    this.taskService.editTask(index);
  }
}
