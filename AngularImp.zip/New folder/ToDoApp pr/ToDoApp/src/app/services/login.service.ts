import { Injectable } from '@angular/core';
import { LoginCredentialsModel } from '../model/login-credentials-model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  correctCredentials: LoginCredentialsModel;
  constructor() {
    // sets default correct credentials
    this.correctCredentials = new LoginCredentialsModel();
    this.correctCredentials.email = 'admin@gmail.com';
    this.correctCredentials.password = '123456';
  }
}
