import { Product } from './product';

export class Item {
    quantity: number;
    price: number;

}