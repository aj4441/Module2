import { Product } from './Product';


export class Item {

    product: Product;
    quantity: number;

}