import { Injectable } from '@angular/core';
import { UserModel } from '../Model/User';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userArr: UserModel[];

  constructor(private routes: Router) { 
    this.userArr = [];
  }
  add(user: UserModel) {
  
    this.userArr.push(user);
    this.routes.navigate(['/todoo']);
  }
  getUsers() {
    console.log(this.userArr);
    return this.userArr;
  }
  
  delete(i: number) {
    this.userArr.splice(i, 1);
  }

}
