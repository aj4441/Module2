import { Component, OnInit } from '@angular/core';
import { UserModel } from '../Model/User';
import { Router } from '@angular/router';
import { UserService } from '../Service/user.service';

@Component({
  selector: 'app-userinfo',
  templateUrl: './userinfo.component.html',
  styleUrls: ['./userinfo.component.css']
})
export class UserinfoComponent implements OnInit {
  userArr: UserModel[];
  confirmationStatus;


  constructor(private userService: UserService, private router: Router) {
    this.userArr = [];
  }

  ngOnInit() {
    this.userArr = this.userService.getUsers();
  }

  delete(index: number) {
   
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.userService.delete(index);
    }
  }
 


}
