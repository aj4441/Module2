import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../Service/user.service';
import { UserModel } from '../Model/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  input: UserModel;
  incorrectEmailStatus = false;
  incorrectPasswordStatus = false;
  requiredEmailStatus = false;
  requiredPasswordStatus = false;
  constructor(private router: Router, private userService: UserService) {
    this.input = new UserModel();
    this.input.userEmailAddress = '';
    this.input.userPassword = '';
  }


  navigateToHome() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['/home']);
  }
  validate() {
    // validates email
    if (this.input.userEmailAddress !== '') {
      if (this.userService.correctCredentials.userEmailAddress !== this.input.userEmailAddress) {
        this.incorrectEmailStatus = true;
        this.requiredEmailStatus = false;    
      }
    } else {
      this.requiredEmailStatus = true;
    }
    // validates password
    if (this.input.userPassword !== '') {
      if (this.userService.correctCredentials.userPassword !== this.input.userPassword) {
        this.incorrectPasswordStatus = true;
        this.requiredPasswordStatus = false;
      }
    } else {
      this.requiredPasswordStatus = true;
    }
    // validates for correct credentials
    if (this.userService.correctCredentials.userEmailAddress === this.input.userEmailAddress &&
      this.userService.correctCredentials.userPassword === this.input.userPassword) {
        this.router.navigate(['/userinfo']);
    }
  }

  ngOnInit() {
  }

}
