export class UserModel {  //to create an class of user

    public userEmailAddress: String;
    public userPassword: String;
    public userFirstName: String;
    public userLastName: String;
    
}