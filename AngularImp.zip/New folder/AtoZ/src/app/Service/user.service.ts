import { Injectable } from '@angular/core';
import { UserModel } from '../Model/User';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  correctCredentials: UserModel;
  userArr: UserModel[];

  constructor(private routes: Router) {
     // sets default correct credentials
     this.correctCredentials = new UserModel();
     this.correctCredentials.userEmailAddress = 'admin@gmail.com';
     this.correctCredentials.userPassword= '123456';
    this.userArr = [];
  }
  add(user: UserModel) {
    // add task to array
    this.userArr.push(user);
    this.routes.navigate(['/todoo']);
  }
  getUsers() {
    console.log(this.userArr);
    return this.userArr;
  }
  delete(i: number) {
    this.userArr.splice(i, 1);
  }

}
