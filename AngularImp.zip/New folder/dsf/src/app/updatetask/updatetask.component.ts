import { Component, OnInit } from '@angular/core';
import { UserModel } from '../Model/User';
import { ActivatedRoute, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { UserService } from '../Service/user.service';

@Component({
  selector: 'app-updatetask',
  templateUrl: './updatetask.component.html',
  styleUrls: ['./updatetask.component.css']
})
export class UpdatetaskComponent implements OnInit {
  updatedTask: UserModel;
  paramIndex = 0;

  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) {
    this.updatedTask = new UserModel();
  }
  ngOnInit() {
    if (window.location.search !== '') {
      // take id from route query param and prefill data of particular task
      this.route.queryParams.pipe(
        filter(params => params.id))
        .subscribe(params => {
          console.log(params.id);
          this.paramIndex = params.id;
          this.updatedTask = this.userService.getDetailsOf(this.paramIndex);
          console.log(this.updatedTask)
        });
    }
  }
  updateTask() {
    // send index of task and updated details
    this.userService.edit(this.paramIndex, this.updatedTask);
  }
}





