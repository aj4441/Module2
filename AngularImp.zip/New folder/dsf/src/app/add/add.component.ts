import { Component, OnInit, Input } from '@angular/core';
import { UserModel } from '../Model/User';
import { UserService } from '../Service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  //to create new user or edit it
@Input() user: UserModel;

  constructor(private routes: Router, private usService: UserService) { 
    this.user = new UserModel;
  }
  public onSubmitClick() {
    this.usService.add(this.user);
    this.user = new UserModel();
     // navigate to userinfo page on click of submit button
    this.routes.navigate(['/userinfo']);
  }
  public backtoAddClick(){
     // navigate to add page on click of back to Add button
    this.routes.navigate(['/add']);   
 }
  ngOnInit() {
  }

}
