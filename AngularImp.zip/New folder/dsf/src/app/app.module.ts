import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AddComponent } from './add/add.component';
import { UserinfoComponent } from './userinfo/userinfo.component';
import { UserService } from './Service/user.service';
import { UpdatetaskComponent } from './updatetask/updatetask.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component:HomeComponent , pathMatch: 'full' },
  { path: 'login', component:LoginComponent , pathMatch: 'full' },
  { path: 'add', component:AddComponent , pathMatch: 'full' },
  { path: 'userinfo', component:UserinfoComponent , pathMatch: 'full' },
  { path: 'updatetask', component:UpdatetaskComponent , pathMatch: 'full' },
  { path: '**', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AddComponent,
    UserinfoComponent,
    UpdatetaskComponent,
  
    
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
