import { Injectable } from '@angular/core';
import { UserModel } from '../Model/User';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userArr: UserModel[];

  constructor(private routes: Router) { 
    this.userArr = [];
  }
  add(user: UserModel) {
    // add task to array
    this.userArr.push(user);
    this.routes.navigate(['/todoo']);
  }
  getUsers() {
    console.log(this.userArr);
    return this.userArr;
  }
  checkUser(username: string, password: string) {
    if (username == "admin@gmail.com" && password == "4441") {
      this.routes.navigate(['/add']);
    }
  }
  delete(i: number) {
    this.userArr.splice(i, 1);
  }
  editTask(index: number) {
    // add id of task through route to prefill and edit particular task
    console.log(index)
    this.routes.navigate(['/updatetask'], { queryParams: { id: index } });
  }
  getDetailsOf(index) {
    // get details of particular task
    return this.userArr[index];
  }
  edit(index: number, updatedTask: UserModel) {
    // update edited task details to array
    this.userArr[index] = updatedTask;
    this.routes.navigate(['/userinfo']);
  }

}
