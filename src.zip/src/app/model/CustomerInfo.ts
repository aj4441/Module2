export class CustomerModel {

    public customerId: number;
    public customerName: String;
    public customerAddress: String;
    public customerGender: String;
    public customerMobNo: number;


}