import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/CustomerInfo';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customerArr: CustomerModel[];

  constructor(private routes: Router) {
    this.customerArr = [];
  }

  add(employee: CustomerModel) {
    employee.customerId = Math.floor(Math.random() * 100);
    this.customerArr.push(employee);
    this.routes.navigate(['/display']);
  }

  getEmployees() {
    return this.customerArr;
  }
  delete(index: number) {
    this.customerArr.splice(index, 1);
  }
}
