import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CustomerModel } from '../model/CustomerInfo';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  //to create new employee or edit it
  @Input() customer: CustomerModel;

  @Output() edited = new EventEmitter();

  //initilize it
  constructor(private custService: CustomerService) {
    this.customer = new CustomerModel;
  }


  add() {
    this.custService.add(this.customer);
    this.customer = new CustomerModel();
  }
  ngOnInit() {
  }

}
