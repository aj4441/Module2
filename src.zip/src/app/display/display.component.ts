import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/CustomerInfo';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  customerArr: CustomerModel[];


  constructor(private custService: CustomerService) {
    this.customerArr = [];

  }

  ngOnInit() {
    this.customerArr = this.custService.getEmployees();
  }
  delete(index: number) {
    this.custService.delete(index);
   }
 
   
}

