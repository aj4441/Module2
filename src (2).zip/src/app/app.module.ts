import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';



import { AppComponent } from './app.component';
import { GreetComponent } from './greet.component';
import { LoginComponent } from './login.component';


@NgModule({
  declarations: [
    AppComponent, GreetComponent, LoginComponent
  ],
  imports: [
    BrowserModule, FormsModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

