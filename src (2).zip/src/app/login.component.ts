

import { Component } from '@angular/core';

@Component({
    selector: "login",
    templateUrl: "./login.Component.html"
    
})
export class LoginComponent {
    userid : string;
    password : string;
    roles : string[];
    submitted : boolean;
    selected : string;

    constructor(){
        this.roles = ['Admin','User','Guest'];
        this.userid="Ajay";
        this.password="asdf";
    }

    validate(){
        this.submitted= true;
        console.log(this.userid + "=" + this.password);
    }
}


